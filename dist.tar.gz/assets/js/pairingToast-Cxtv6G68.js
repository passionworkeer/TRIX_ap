import{c as a}from"./index-CeRcKFyV.js";
/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=a("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]),r="pairing-required",s="请先完成 TRIX Bot 配对",e={id:r,duration:1600};export{i as C,s as P,e as a,r as b};
